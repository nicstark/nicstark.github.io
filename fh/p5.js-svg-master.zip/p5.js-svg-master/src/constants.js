var constants = {
    SVG: 'svg'
};

module.exports = constants;
