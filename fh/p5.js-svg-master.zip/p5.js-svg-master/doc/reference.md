API reference for p5.SVG.
